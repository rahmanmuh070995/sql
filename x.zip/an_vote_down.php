<?php session_start();

include("db.php");

$id=$_POST['id'];

$id = $mysqli->real_escape_string($id);

if(!isset($_SESSION['username'])){
?>

<script>
$("#freeow").freeow("Mmmm..", "You have login to vote", {
classes: ["smokey", "error"],
autoHide: true
});
</script>

<?php
}else{
	
$Uname = $_SESSION['username'];

if($UserSql = $mysqli->query("SELECT * FROM users WHERE username='$Uname'")){

    $UserRow = mysqli_fetch_array($UserSql);

	$Uid = $UserRow['uid'];
	
	$UserSql->close();
	
}else{
     
	 printf("Error: %s\n", $mysqli->error);
	 
}



$ip=$_SERVER['REMOTE_ADDR']; 

if($_POST['id'])
{

$CheckIp = $mysqli->query("SELECT * FROM an_votes WHERE aid='$id' AND uid='$Uid'");
$VoteType = mysqli_fetch_array($CheckIp);

$Vote = $VoteType['type'];

$Count = mysqli_num_rows($CheckIp);

if($Count==0)
{
	$Sql = $mysqli->query("UPDATE answers SET votes=votes-1 WHERE id='$id'");
	$SqlIn = $mysqli->query("INSERT INTO an_votes (aid,ip,uid,type) VALUES ('$id','$ip','$Uid','2')");

}else{
//Get vote up or down

if ($Vote==1){
	
	$AddVote = $mysqli->query("UPDATE answers SET votes=votes-1 WHERE id='$id'");
	$UpdateVote = $mysqli->query("UPDATE an_votes SET type='2' WHERE aid='$id'");
	
} elseif ($Vote==2){
		
	$RemoveVote	= $mysqli->query("UPDATE answers SET votes=votes+1 WHERE id='$id'");
	$DeleteVote = $mysqli->query("DELETE FROM an_votes WHERE aid='$id'");
	
}

// End vote up down
}

}

}

$result=$mysqli->query("SELECT votes FROM answers WHERE id='$id'");
$row=mysqli_fetch_array($result);

echo $row['votes'];
?>