<?php
session_start();

include('db.php');

if($squ = $mysqli->query("SELECT * FROM settings WHERE id='1'")){

    $settings = mysqli_fetch_array($squ);
	
	$Points = $settings['qpts'];
	
	$squ->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

//User Details

if(!isset($_SESSION['username'])){
	//Do Nothing
}else{
	
$Uname = $_SESSION['username'];

if($UserSql = $mysqli->query("SELECT * FROM users WHERE username='$Uname'")){

    $UserRow = mysqli_fetch_array($UserSql);

	$Uid = $UserRow['uid'];
	
	$UserSql->close();
	
}else{
	
     printf("Error: %s\n", $mysqli->error);

}

}

if($_POST)
{		
	if(!isset($_POST['catagory-select']) || strlen($_POST['catagory-select'])<1)
	{
		//required variables are empty
		die('<div class="msg-error">Please select a category.</div>');
	}
	
	if(!isset($_POST['title']) || strlen($_POST['title'])<1)
	{
		//required variables are empty
		die('<div class="msg-error">Please ask your question.</div>');
	}
	
			
	
	$Date		        = date("c",time());
	
	$Category           = $mysqli->escape_string($_POST['catagory-select']);
	$Question       	= $mysqli->escape_string($_POST['question']);
	$Title		 		= $mysqli->escape_string($_POST['title']);
	$Approve			=1;
		
	
// Insert info into database table.. do w.e!
		$mysqli->query("INSERT INTO questions(title, question, catid, userid, date, active) VALUES ('$Title','$Question ','$Category','$Uid','$Date','$Approve')");
		
		$mysqli->query("UPDATE users SET points=points+'$Points' WHERE uid='$Uid'");

?>
<script>
$('#FromQuestion').delay(500).slideUp(1000);
$('#FromQuestion').delay(1000).resetForm(1000);
</script>
<?php	
		
		die('<div class="msg-ok">Your question has been successfully submitted.</div>');
   
   }else{
	   
   		die('<div class="msg-error">There seems to be a problem. please try again.</div>');
   
   } 

?>