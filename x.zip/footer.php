</div><!--container-->

<footer id="main-footer">

<div id="footer-center">
<div class="footer-data"><a class="footer-links"  href="about_us.html">About Us</a> | <a class="footer-links"  href="privacy_policy.html">Privacy Policy</a> | <a class="footer-links"  href="tos.html">Terms of Use</a> | <a class="footer-links"  href="faq.html">FAQ</a> | <a class="footer-links" href="contact_us.html">Contact Us</a></div>
<div class="footer-txt">Copyright © <?php echo date("Y");?> <?php echo $settings['name'];?>. All Rights Reserved.</div>
</div><!--footer-center-->

</footer><!--main-footer-->
</body>
</html>