<?php session_start();

include('db.php');

if($squ = $mysqli->query("SELECT * FROM settings WHERE id='1'")){

    $settings = mysqli_fetch_array($squ);
	
	$template = $settings['template'];
	
	$squ->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

//User Info

if(!isset($_SESSION['username'])){
	
	$Uid = 0;

}else{
	
$Uname = $_SESSION['username'];

if($UserSql = $mysqli->query("SELECT * FROM users WHERE username='$Uname'")){

    $UserRow = mysqli_fetch_array($UserSql);
	
	$UsName = strtolower($UserRow['username']);

	$Uid = $UserRow['uid'];
	
	$UserEmail = $UserRow['email'];
	
	$Uavatar = $UserRow['avatar'];

    $UserSql->close();
	
}else{
     
	 printf("Error: %s\n", $mysqli->error);
	 
}

}

//Info

$qid = $mysqli->escape_string($_GET['id']);

$UpdateViews = $mysqli->query("UPDATE questions SET views=views+1 WHERE id='$qid'");

if($Questions = $mysqli->query("SELECT * FROM questions WHERE id='$qid'")){

    $QuestionRow = mysqli_fetch_array($Questions);
	
	$Quid = $QuestionRow['userid'];
	
	$QuestionId = $QuestionRow['id'];
	
   	$QuestionVotes = $QuestionRow['votes'];
	
	$QuestionAnswers = $QuestionRow['answers'];
	
	$Questions->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}	


if($Users = $mysqli->query("SELECT * FROM users WHERE uid='$Quid'")){

    $UsersnRow = mysqli_fetch_array($Users);
	
	$QuestionUserId = $UsersnRow['uid'];
	
	$QuestionUserName = $UsersnRow['username'];
	
	$Users->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

//Meta Description

$QuestionMeta = stripslashes($QuestionRow['question']);

	$Str = strlen ($QuestionMeta);
	
if ($Str > 200) {
	
	$MetaDes = substr($QuestionMeta,0,200);

}else{
	
	$MetaDes = $QuestionMeta;}


//Ads

if($AdsSql = $mysqli->query("SELECT * FROM siteads WHERE id='1'")){

    $AdsRow = mysqli_fetch_array($AdsSql);
	
	$Ad1 = $AdsRow['ad1'];
	$Ad2 = $AdsRow['ad2'];
	
    $AdsSql->close();

}else{
	
     printf("Error: %s\n", $mysqli->error);
}	

//Notification

if(isset($_SESSION['username'])){

if($QuestionUserId==$Uid){

$ViewdNote = $mysqli->query("UPDATE answers SET viewd=1 WHERE qid='$qid'");

$ViewdNew = $mysqli->query("UPDATE questions SET new_answers=0 WHERE id='$qid'");

}
}

$UpdateSiteViews = $mysqli->query("UPDATE settings SET site_hits=site_hits+1 WHERE id=1");

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo stripslashes($QuestionRow['title']);?> | <?php echo $settings['name']; ?></title>
<meta name="description" content="<?php echo $MetaDes; ?>" />
<meta name="keywords" content="<?php echo $settings['keywords']; ?>" />

<link href="favicon.ico" rel="shortcut icon" type="image/x-icon"/>

<link href="templates/<?php echo $settings['template'];?>/css/style.css" rel="stylesheet" type="text/css">

<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript" src="js/jquery.freeow.min.js"></script>
<script src="js/jquery.timeago.js" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function(){
	$(".login-links").colorbox();
	$(".loginbox").colorbox();
})
jQuery(document).ready(function() {
  jQuery("abbr.timeago").timeago();
});

$(document).scroll(function() {
    
    var useFixedNav = $(document).scrollTop() > 75;
    $('.menu-bar').toggleClass('menu-bar-fixed', useFixedNav);
    
});

$(function() {
$(".vote").click(function()
{
var id = $(this).attr("id");
var name = $(this).attr("name");
var dataString = 'id='+ id ;
var parent = $(this);

if (name=='up')
{
$(this).fadeIn(200).html;
$.ajax({
type: "POST",
url: "qu_vote_up.php",
data: dataString,
cache: false,

success: function(html)
{
$("#display-vote").html(html);
}
});
}
else
{
$(this).fadeIn(200).html;
$.ajax({
type: "POST",
url: "qu_vote_down.php",
data: dataString,
cache: false,

success: function(html)
{
$("#display-vote").html(html);
}
});
}
return false;
});
});
//answer votes
$(function() {
$(".answer-vote").click(function()
{
var id = $(this).attr("id");
var name = $(this).attr("name");
var dataString = 'id='+ id ;
//var dataId = id;
var parent = $(this);

if (name=='answer-up')
{
$(this).fadeIn(200).html;
$.ajax({
type: "POST",
url: "an_vote_up.php",
data: dataString,
cache: false,

success: function(html)
{
parent.parent().find(".answer-display-vote").html(html);
}
});
}
else
{
$(this).fadeIn(200).html;
$.ajax({
type: "POST",
url: "an_vote_down.php",
data: dataString,
cache: false,

success: function(html)
{
parent.parent().find(".answer-display-vote").html(html);
}
});
}
return false;
});
});
</script>
</head>

<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=196505667225847";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<header id="main-header">
<section id="head-container">
<div id="logo"><a href="index.html"><img src="images/logo.png" alt="<?php echo $settings['name'];?>" width="200" height="70"></a></div>
<div id="login-box">
<?php if(!isset($_SESSION['username'])){?>
<a href="login.html" class="login-links">Login</a> | <a href="register.html" class="login-links">Register</a>
<?php }else{ ?>
Welcome <?php echo ucfirst($_SESSION['username']);}?>
</div><!--login-box-->
</section><!--head-container-->

<div class="menu-bar">
<div id="menu-center">
<nav id="top-menu">
<ul>
   <li class='active'><a href='index.html'><span>Home</span></a></li>
   <li><a href="all.html"><span>All Questions</span></a></li>
   <li><a href="answerd.html"><span>Answerd</span></a></li>
   <li><a href="unanswered.html"><span>Unanswered</span></a></li>
   <li class="last"><a href="ask.html"><span>Ask</span></a></li>
</ul>
</nav>

<div class="search-box">
<form name="search" id="search" method="get" action="search.php">
<input type="text" tabindex="1" class="input" id="term" name="term" placeholder="Search questions and answers"/>
<button type="submit" tabindex="2" class="form-button" id="submit-search">Search</button>
</form>
</div>

</div><!--menu-center-->
</div><!--menu-bar-->
</header>
<div id="container">
<div id="freeow" class="freeow freeow-top-right"></div>