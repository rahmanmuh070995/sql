<?php if(isset($_SESSION['username'])){?>
<div class="right-box">
<div class="box-title"><h1><?php echo ucfirst($_SESSION['username']);?></h1></div>
<nav class="right-menu">
<ul>
<li><a href="profile-<?php echo $Uid;?>-<?php echo $UsName;?>.html"><span>My Profile</span></a></li>
<li><a href="edit_profile.html"><span>Edit info</span></a></li>

<?php

$NewAnswers = $mysqli->query("SELECT * FROM answers LEFT JOIN questions ON questions.id=answers.qid WHERE questions.userid='$Uid' and answers.viewd=0");

//$NewAnswers = $mysqli->query("SELECT id, uid, viewd FROM answers WHERE uid='$Uid' and viewd=0");

   $NewAnswersCnt = mysqli_num_rows($NewAnswers);

if ($NewAnswersCnt>0){	
?>
<li><a href="new.html"><span>New Answers&nbsp; <span class="new-answers"><?php echo $NewAnswersCnt;?></span></span></a></li>
<?php }?>

<li><a href="logout.php"><span>Logout</span></a></li>
</ul>
</nav><!--right-menu-->
</div><!--right-box-->
<?php }?>


<div class="right-box">
<div class="box-title"><h1>Categories</h1></div>
<nav class="right-menu">
<ul>
<?php
if($CatSql = $mysqli->query("SELECT id, cname FROM categories")){

    while($CatRow = mysqli_fetch_array($CatSql)){
		
		$CatName = $CatRow['cname'];
		$CatUrl = preg_replace("![^a-z0-9]+!i", "-", $CatName);
		$CatURl = urlencode($CatUrl);
		$CatUrl = strtolower($CatUrl);
		
		$CatDisplayName = str_replace('&','&amp;',$CatName);
		
?>
    <li><a href="category-<?php echo $CatRow['id'];?>-<?php echo $CatUrl;?>-1.html"><span><?php echo $CatDisplayName;?></span></a></li>
<?php

}

	$CatSql->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}
?>   
   
</ul>
</nav><!--right-menu-->
</div><!--right-box-->

<?php if(!empty($Ad2)){ ?>
<div class="right-ads">
<?php echo stripslashes($Ad2);?>
</div><!--right-ads-->
<?php } ?>


