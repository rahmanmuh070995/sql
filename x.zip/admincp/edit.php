<?php
include('../db.php');

$id = $mysqli->escape_string($_GET['id']);

if($_POST)
{		
		if(!isset($_POST['catagory-select']) || strlen($_POST['catagory-select'])<1)
	{
		//required variables are empty
		die('<div class="msg-error">Please select a category.</div>');
	}
	
	if(!isset($_POST['title']) || strlen($_POST['title'])<1)
	{
		//required variables are empty
		die('<div class="msg-error">Please ask your question.</div>');
	}

	
	
	$Category           = $mysqli->escape_string($_POST['catagory-select']);
	$Question       	= $mysqli->escape_string($_POST['question']);
	$Title		 		= $mysqli->escape_string($_POST['title']);
	
	
		
		
		$mysqli->query("UPDATE questions SET title='$Title',question='$Question',catid='$Category' WHERE id=$id");
		
		die('<div class="msg-ok">Question updated successfully.</div>');
		
   
   }else{
   		die('<div class="msg-error">There seems to be a problem. please try again.</div>');
   } 

?>