<?php include("header.php");?>
<div class="maintitle">Edit Rank</div>
<?php

$Edit = $mysqli->escape_string($_GET['edit']);

$act=isset($_GET['act'])?$_GET['act']:"";
if($act=='sub'){
	
$Rank = $mysqli->escape_string($_POST['rank']);
$Pts = $mysqli->escape_string($_POST['pts']);

$update = $mysqli->query("UPDATE ranks SET rank='$Rank',points='$Pts' WHERE id='$Edit'") 
or die(mysqli_error());?>
<div class="msg-ok">Rank has been updated successfully</div>
<?php }
$qu=$mysqli->query("SELECT * FROM ranks WHERE id='$Edit'") or die (mysqli_error());
$row= mysqli_fetch_array($qu);
?>

<div class="box">
<div class="inbox">
<form name="newcat" action="editrank.php?act=sub&edit=<?php echo $Edit;?>" method="post">

<label class="artlbl" for="cat">Rank:</label>
<div class="formdiv"><input  name="rank" class="biginput" type="text" value="<?php echo $row['rank'];?>"/></div>

<label class="artlbl" for="cat">Points Required:</label>
<div class="formdiv"><input  name="pts" class="biginput" type="text" value="<?php echo $row['points'];?>"/></div>
</div>

<div class="formdiv">
<div class="sbutton"><input type="submit" id="submit"value='Update Rank'/></div>
</div>
</form>	
</div>
</div>
<?php include("footer.php");?>