<?php include("header.php");

$id = $mysqli->escape_string($_GET['id']);

?>
<div class="maintitle">Edit Question</div>

<script>
$(document).ready(function()
{
    $('#EditQuestion').on('submit', function(e)
    {
        e.preventDefault();
        $('#submit').attr('disabled', ''); // disable upload button
        //show uploading message
        
        $(this).ajaxSubmit({
        target: '#output',
        success:  afterSuccess //call function after success
        });
    });
});
 
function afterSuccess()
{
    //$('#EditQuestion').resetForm();  // reset form
    $('#submit').removeAttr('disabled'); //enable submit button
    $('#loadding').html('');
}

$(document).ready(function() {
      var characters = 140;
    $("#counter").append("You have <strong>"+  characters+"</strong> characters remaining");
    $("#title").keyup(function(){
        if($(this).val().length > characters){
        $(this).val($(this).val().substr(0, characters));
        }
    var remaining = characters -  $(this).val().length;
    $("#counter").html("You have <strong>"+  remaining+"</strong> characters remaining");
    if(remaining <= 10)
    {
        $("#counter").css("color","red");
    }
    else
    {
        $("#counter").css("color","black");
    }
    });
        });

</script>

<?php

if($q = $mysqli->query("SELECT * FROM questions WHERE id='$id'")){

    $s = mysqli_fetch_array($q);
	$ncid = $s['catid'];
	$q->close();
}else{
     printf("Error: %s\n", $mysqli->error);
}
?>

<div id="loadding"></div>
<div id="output"></div>

<div class="box">
<div class="inbox">
<form action="edit.php?id=<?php echo $id?>" id="EditQuestion" method="post">

<label class="artlbl" for="cat">Category:</label>
<div class="formdiv">
<select name="catagory-select" id="catagory-select">

<?php
if($CatSelected = $mysqli->query("SELECT * FROM categories WHERE id=$ncid LIMIT 1")){

($CatSelectedRow = mysqli_fetch_array($CatSelected))
		
?>   
	<option value="<?php echo $CatSelectedRow['id'];?>"><?php echo $CatSelectedRow['cname'];?></option>
<?php     
	
$CatSelected->close();
}else{
     printf("Error: %s\n", $mysqli->error);
}
?>

<option disabled value="">--- Choose a different category ----</option>

<?php
if($CatSql = $mysqli->query("SELECT * FROM categories ORDER BY cname ASC")){

    while ($CatRow = mysqli_fetch_array($CatSql)){
		
?>   
	<option value="<?php echo $CatRow['id'];?>"><?php echo $CatRow['cname'];?></option>
<?php     
	}
$CatSql->close();
}else{
     printf("Error: %s\n", $mysqli->error);
}
?>
</select>
</div>
<div class="clear"></div>

<label class="artlbl">Question
<span class="small">Brief description of your question</span>
</label>
<div class="formdiv">
<input type="text" name="title" id="title" value="<?php echo $s['title'];?>" /> 
<div  id="counter"></div>
</div>

<label class="artlbl">Question Details
<span class="small">Ask with more details (optional)</span>
</label>
<div class="formdiv">
<textarea name="question" id="question"><?php echo $s['question'];?></textarea>
</div>


<div class="formdiv">
<div class="sbutton"><input type="submit" id="submit" value="Update Question"/></div>
</div>
</form>	
</div>
</div>
<?php include("footer.php");?>