<?php include('header.php');?>
<div id="left">

<?php

$pid = $mysqli->escape_string($_GET['id']);

if($Profile = $mysqli->query("SELECT * FROM users WHERE uid='$pid'")){

    $ProfileInfo = mysqli_fetch_array($Profile);
	
	$ProfileAvatar = $ProfileInfo['avatar'];
	
	$BirthDay = $ProfileInfo['birthday'];
	
	$Country = $ProfileInfo['country'];
	
	$AboutMe = $ProfileInfo['about'];
	
	$ProfilePoints = $ProfileInfo['points'];
	
	$Profile->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}


//Get Rank

//SELECT title FROM ptb WHERE pts <= $points ORDER BY pts DESC LIMIT 1
if($MyRank = $mysqli->query("SELECT * FROM ranks WHERE points<=$ProfilePoints ORDER BY points DESC LIMIT 1")){

    $RankInfo = mysqli_fetch_array($MyRank);
	
	$GetRank = $RankInfo['rank'];
	
	$MyRank->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}


//Get Birthday

function getAge($then) {
    $then_ts = strtotime($then);
    $then_year = date('Y', $then_ts);
    $age = date('Y') - $then_year;
    if(strtotime('+' . $age . ' years', $then_ts) > time()) $age--;
    return $age;
}

// Count questions

if ($TotQuestions = $mysqli->query("SELECT userid FROM questions WHERE userid='$pid'")) {

    $QuestionsCnt = $TotQuestions->num_rows;

    $TotQuestions->close();
}

// Count Answers

if ($TotAnswers = $mysqli->query("SELECT uid FROM answers WHERE uid='$pid'")) {

    $AnswerCnt = $TotAnswers->num_rows;

    $TotAnswers->close();
}

?>

<div class="title"><h1><?php echo ucfirst($ProfileInfo['username']);?> Profile</h1></div>

<div id="profile-box">

<div class="profile-picture">
<?php if (empty($ProfileAvatar)){ ?>
<img src="templates/<?php echo $settings['template'];?>/images/default-avatar.png" width="200" height="200" class="avatar-img">
<?php }elseif (!empty($ProfileAvatar)){?>
<img src="timthumb.php?src=http://<?php echo $settings['siteurl'];?>/avatars/<?php echo $ProfileAvatar;?>&amp;h=200&amp;w=200&amp;q=100" alt="User Avatar" class="avatar-img"/>
<?php } ?>
</div><!--Profile-Picture-->

<div class="profile-info">
<div class="info-row"><strong>Country :</strong> <?php if(!empty($Country)){ echo ucfirst($Country);}else{?>Not specified<?php }?></div>
<div class="info-row"><strong>Birth Date :</strong> <?php if(!empty($BirthDay)){ echo $BirthDay;?> (<?php print getAge($BirthDay);?> years old)<?php }else{?>Not specified<?php }?></div>
<div class="info-row"><strong>Number of questions :</strong> <?php echo $QuestionsCnt;?></div>
<div class="info-row"><strong>Number of Answers :</strong> <?php echo $AnswerCnt;?></div>
<div class="info-row"><strong>Rank :</strong> <?php echo $GetRank;?> (<?php echo $ProfilePoints;?> Points)</div>
</div><!--profile-info-->

<div class="about-row"><strong>About <?php echo ucfirst($ProfileInfo['username']);?>:</strong> <p><?php if (!empty($AboutMe)){echo stripslashes(ucfirst($AboutMe));}else{ echo ucfirst($ProfileInfo['username'])?>  hasn't written an 'About Me' yet.<?php }?></p>
</div>

</div><!--profile-box-->


<div class="title"><h1>Questions</h1></div>


<?php if($QuestionsCnt<1){?>
<div class="no-results"><?php echo ucfirst($ProfileInfo['username']);?> hasn't asked any questions yet</div><!--no-results-->
<?php }

if($UserQuestions = $mysqli->query("SELECT * FROM questions LEFT JOIN users ON users.uid=questions.userid WHERE questions.userid=users.uid and questions.active=1 and questions.userid='$pid' ORDER BY questions.id DESC LIMIT 10")){

    while($UqRow = mysqli_fetch_array($UserQuestions)){
		
		$QuName = strtolower($UqRow['username']);
				
?>
<div class="qu-box">
<div class="av-box"><span class="big"><?php echo $UqRow['answers'];?></span><br/>Answers</div><!--answers-->
<div class="av-box"><span class="big"><?php echo $UqRow['views'];?></span><br/>Views</div><!--answers-->
<header class="qu-title">
<a href="question-<?php echo $UqRow['id'];?>.html"><h2><?php echo stripslashes($UqRow['title']);?></h2></a>
</header>
<footer class="details"><a href="profile-<?php echo $UqRow['userid'];?>-<?php echo $QuName;?>.html"><?php echo $ProfileInfo['username'];?></a> asked <abbr class="timeago" title="<?php echo $UqRow['date'];?>"></abbr></footer>
</div><!--qu-box-->
<?php

}

	$UserQuestions->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

if($QuestionsCnt>10){?>

<div class="more-results"><a href="userq-<?php echo $pid;?>-1.html">All questions by <?php echo ucfirst($ProfileInfo['username']);?> &#187;</a></div><!--no-results-->

<?php }?>

<div class="title"><h1>Answers</h1></div>

<?php if ($AnswerCnt<1){?>
<div class="no-results"><?php echo ucfirst($ProfileInfo['username']);?> hasn't answerd any questions yet</div><!--no-results-->
<?php
}

if($LestSql = $mysqli->query("SELECT * FROM answers LEFT JOIN questions ON questions.id=answers.qid WHERE answers.uid='$pid' GROUP BY answers.qid LIMIT 10")){
	
    while($LatestRow = mysqli_fetch_array($LestSql)){
			
		$AuName = strtolower($LatestRow['username']);	
		
				
?>
<div class="qu-box">
<div class="av-box"><span class="big"><?php echo $LatestRow['answers'];?></span><br/>Answers</div><!--answers-->
<div class="av-box"><span class="big"><?php echo $LatestRow['views'];?></span><br/>Views</div><!--answers-->
<header class="qu-title">
<a href="question-<?php echo $LatestRow['id'];?>.html"><h2><?php echo stripslashes($LatestRow['title']);?></h2></a>
</header>
<footer class="details"><a href="profile-<?php echo $LatestRow['userid'];?>-<?php echo $AuName;?>.html"><?php echo $LatestRow['username'];?></a> asked <abbr class="timeago" title="<?php echo $LatestRow['date'];?>"></abbr></footer>
</div><!--qu-box-->
<?php

}

	$LestSql->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

if ($AnswerCnt>10){?>

<div class="more-results"><a href="usera-<?php echo $pid;?>-1.html">All questions answerd by <?php echo ucfirst($ProfileInfo['username']);?> &#187;</a></div><!--no-results-->
<?php }?>

</div><!--left-->

<div id="right">
<?php include('side_bar.php');?>
</div><!--right-->

<?php include('footer.php');?>