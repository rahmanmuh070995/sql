<?php include('header_qu.php');?>

<div id="left">

<div class="qu-details">

<div id="q-vote">

<a href="" class="vote up" id="<?php echo $QuestionId; ?>" name="up"></a>

<div id="display-vote"><?php echo $QuestionVotes; ?></div>

<a href="" class="vote down" id="<?php echo $QuestionId; ?>" name="down"></a>

</div><!--q-vote-->

<header class="qu-page-title"><h2><?php echo stripslashes($QuestionRow['title']);?></h2></header>
<div class="qu-page-details"><a href="profile-<?php echo $QuestionUserId;?>-<?php echo $QuestionUserName;?>.html"><?php echo $UsersnRow['username'];?></a> asked <abbr class="timeago" title="<?php echo $QuestionRow['date'];?>"></abbr></div>

<aside class="qu-txt">
<p><?php echo nl2br(stripslashes($QuestionRow['question']));?></p>
</aside>
<footer class="qu-footer">
<div class="quf-left">

</div>
<div class="quf-right">
<div class="qu-social">
<div class="fb-like" data-href="https://<?php echo $settings['siteurl'];?>/question-<?php echo $QuestionRow['id'];?>.html" data-layout="button_count" data-action="like" data-show-faces="false" data-share="false"></div>
</div><!--qu-social-->

<div class="qu-social">
<a href="https://twitter.com/share" class="twitter-share-button" data-url="https://<?php echo $settings['siteurl'];?>/question-<?php echo $QuestionRow['id'];?>.html">Tweet</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
</div><!--qu-social-->

</div><!--qu-footer-->
</footer>
</div><!--qu-details-->

<?php if(!empty($Ad1)){ ?>
<div class="top-ad">
<?php echo stripslashes($Ad1);?>
</div><!--top-ad-->
<?php } ?>

<!--Answers-->

<div class="title"><h1>Answers</h1></div>

<div id="main">

<div id="addAnswerContainer">
<!--Comments-->
<?php

include ("include/answers.class.php");

//Best Answer
if ($QuestionAnswers > 0){

if($BestAnswer = $mysqli->query("SELECT * FROM answers LEFT JOIN users ON answers.uid=users.uid WHERE answers.qid='$qid' ORDER BY answers.votes DESC LIMIT 1")){

   $Best = mysqli_fetch_array($BestAnswer);
   
   $BestId = $Best['id'];
   $BestVotes = $Best['votes'];
   $BestdBy = $Best['username'];
   $BestFull = $Best['answer'];
   $BestDate = $Best['date']; 
   $BestAvatar = $Best['avatar'];
   $BestUserId = $Best['uid'];
   $BestUserName = strtolower($Best['username']);
         
 ?>

<div class="answer">
			<div class="answer-box">
				<div class="avatar">
                <a href="profile-<?php echo $BestUserId;?>-<?php echo $BestUserName;?>.html">
                <?php	if (empty($BestAvatar)){ 
	echo  '<img src="templates/'.$settings['template'].'/images/default-avatar.png" class="bimg" width="50" height="50">';
		}elseif (!empty($BestAvatar)){

	echo  '<img src="timthumb.php?src=http://'.$settings['siteurl'].'/avatars/'.$BestAvatar.'&amp;h=50&amp;w=50&amp;q=100" alt="User Avatar" class="avatar"/>';
 }?>			</a>
				</div>
				<header class="answer-header">
				<span class="name"><a href="profile-<?php echo $BestUserId;?>-<?php echo $BestUserName;?>.html"><?php echo $BestdBy;?></a></span>
				<span class="date">answered <abbr class="timeago" title="<?php echo $BestDate;?>"></abbr></span>
                <?php if ($BestVotes>0){?><div class="best-answer">Best Answer</div><?php }?>
                </header>
                <aside class="answe-display"><p><?php echo $BestFull;?></p></aside>

</div>

    <div class="answer-bottom">
    
<div class="answer-vote-box">

<a href="" class="answer-vote up" id="<?php echo $BestId; ?>" name="answer-up"></a>

<div class="answer-display-vote" data-id="<?php echo $BestVotes; ?>"><?php echo $BestVotes; ?></div>

<a href="" class="answer-vote down" id="<?php echo $BestId; ?>" name="answer-down"></a>

</div><!--answer-vote-->
    
    </div><!--answer-bottom-->


	
</div><!--answer-->   
 
<?php   

   $BestAnswer->close();
   
}else{
   
     printf("Error: %s\n", $mysqli->error);

}

} //Close Best Answer Condition

if ($QuestionAnswers >1){

// All Answers

if($Answers = $mysqli->query("SELECT * FROM answers LEFT JOIN users ON answers.uid=users.uid WHERE answers.qid='$qid' and answers.id<>$BestId ORDER BY answers.votes DESC")){

   while ($Answer = mysqli_fetch_array($Answers)){
   
   $AnswerId = $Answer['id'];
   $AnswerVotes = $Answer['votes'];
   $AnswerdBy = $Answer['username'];
   $AnswerFull = $Answer['answer'];
   $AnswerDate = $Answer['date']; 
   $AnswerAvatar = $Answer['avatar'];
   $AnswerUserId = $Answer['uid'];
   $AnswerUserName = strtolower($Answer['username']);
         
 ?>

<div class="answer">
			<div class="answer-box">
				<div class="avatar">
                <a href="profile-<?php echo $AnswerUserId;?>-<?php echo $AnswerUserName;?>.html">
                <?php	if (empty($AnswerAvatar)){ 
	echo  '<img src="templates/'.$settings['template'].'/images/default-avatar.png" class="bimg" width="50" height="50">';
		}elseif (!empty($AnswerAvatar)){

	echo  '<img src="timthumb.php?src=http://'.$settings['siteurl'].'/avatars/'.$AnswerAvatar.'&amp;h=50&amp;w=50&amp;q=100" alt="User Avatar" class="avatar"/>';
 }?>			</a>
				</div>
				<header class="answer-header">
				<span class="name"><a href="profile-<?php echo $AnswerUserId;?>-<?php echo $AnswerUserName;?>.html"><?php echo $AnswerdBy;?></a></span>
				<span class="date">answered <abbr class="timeago" title="<?php echo $AnswerDate;?>"></abbr></span>
                </header>
                <aside class="answe-display"><p><?php echo $AnswerFull;?></p></aside>

</div>

    <div class="answer-bottom">
    
<div class="answer-vote-box">

<a href="" class="answer-vote up" id="<?php echo $AnswerId; ?>" name="answer-up"></a>

<div class="answer-display-vote" data-id="<?php echo $AnswerVotes; ?>"><?php echo $AnswerVotes; ?></div>

<a href="" class="answer-vote down" id="<?php echo $AnswerId; ?>" name="answer-down"></a>

</div><!--answer-vote-->
    
    </div><!--answer-bottom-->


	
</div><!--answer-->   
 
<?php   
}
   $Answers->close();
   
}else{
   
     printf("Error: %s\n", $mysqli->error);

}


}//Close All Answer Condition
?>

<?php
if(!isset($_SESSION['username'])){?>


<div class="log-reg">Please <a class="loginbox" href="login.html">login</a> or <a href="register.html" class="loginbox">register</a> to answer this question</div>
<?php }else{
	
if (empty($Uavatar)){ 
	$AvatarImg =  'templates/'.$template.'/images/default-avatar.png" class="bimg';
}elseif (!empty($Uavatar)){
	$AvatarImg =  'avatars/'.$Uavatar;
 }

if ($QuestionAnswers<1){
if($QuestionUserId==$Uid){	
?>
<div class="no-results">There are no answer for your question yet.</div>
<?php }else{?>
<div class="no-results">There are no answer for this question yet. Be the first to answer.</div>
<?php } }

if($QuestionUserId==$Uid){
//do nothing	
}else{
?> 
	

<div id="jr"></div>

<div class="answer-form">	
	<form id="addAnswersForm" method="post" action="">

        	<input type="hidden" name="name" id="name" value="<?php echo $Uname;?>" />
            
            <input type="hidden" name="ruid" id="ruid" value="<?php echo $Uid;?>" />
            
            <input type="hidden" name="avatarlink" id="avatarlink" value="<?php echo $AvatarImg;?>" />
            
            <input type="hidden" name="qid" id="qid" value="<?php echo $QuestionRow['id'];?>" />
            
            <input type="hidden" name="email" id="email" value="<?php echo $UserEmail;?>"/>
                       
           <textarea name="answer" id="answer" cols="20" rows="5"></textarea>
            
            <input type="submit" id="submit" class="btns" value="Submit" /><label class="error"></label>

    </form>
    </div>
 <?php }
 
}
 ?>  
</div>

</div>

<script type="text/javascript" src="js/jquery.answers.js"></script>

<!--Answers-->

</div><!--left-->

<div id="right">
<?php include('side_bar.php');?>
</div><!--right-->

<?php include('footer.php');?>