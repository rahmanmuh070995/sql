<?php session_start();

include("db.php");


$id=$_POST['id'];

$id = $mysqli->real_escape_string($id);

if(!isset($_SESSION['username'])){
?>

<script>
$("#freeow").freeow("Mmmm..", "You have login to vote", {
classes: ["smokey", "error"],
autoHide: true
});
</script>

<?php
}else{
	
$Uname = $_SESSION['username'];

if($UserSql = $mysqli->query("SELECT * FROM users WHERE username='$Uname'")){

    $UserRow = mysqli_fetch_array($UserSql);

	$Uid = $UserRow['uid'];
	
	$UserSql->close();
	
}else{
     
	 printf("Error: %s\n", $mysqli->error);
	 
}



$ip=$_SERVER['REMOTE_ADDR']; 

if($_POST['id'])
{


$CheckIp = $mysqli->query("SELECT * FROM qu_votes WHERE qid='$id' AND uid='$Uid'");
$VoteType = mysqli_fetch_array($CheckIp);

$Vote = $VoteType['type'];

$Count = mysqli_num_rows($CheckIp);

if($Count==0)
{
	$Sql = $mysqli->query("UPDATE questions SET votes=votes+1 WHERE id='$id'");
	$SqlIn = $mysqli->query("INSERT INTO qu_votes (qid,ip,uid,type) VALUES ('$id','$ip','$Uid','1')");

}else{
//Get vote up or down

if ($Vote==1){
	
	$RemoveVote	= $mysqli->query("UPDATE questions SET votes=votes-1 WHERE id='$id'");
	$DeleteVote = $mysqli->query("DELETE FROM qu_votes WHERE qid='$id'");
	
} elseif ($Vote==2){
	$AddVote = $mysqli->query("UPDATE questions SET votes=votes+1 WHERE id='$id'");
	$UpdateVote = $mysqli->query("UPDATE qu_votes SET type='1' WHERE qid='$id'");
	
}

// End vote up down
}


}

}

$result=$mysqli->query("SELECT votes FROM questions WHERE id='$id'");
$row=mysqli_fetch_array($result);

echo $row['votes'];
?>