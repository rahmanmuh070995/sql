<?php include('header.php');?>
<div id="left">

<div class="other-box">

<div class="box-title"><h1>Privacy Policy</h1></div>

<?php
if($pages = $mysqli->query("SELECT * FROM  pages WHERE id='2'")){

    $pagerow = mysqli_fetch_array($pages);
	
?>	

<div class="page"><p><?php echo $pagerow['page'];?></p></div><!--page-->

<?php

    $pages->close();
	
}else{
	
     printf("Error: %s\n", $mysqli->error);
}
?>

</div>

<?php
if(!empty($Ad1)){ ?>
<div class="top-ad">
<?php echo stripslashes($Ad1);?>
</div><!--top-ad-->
<?php } ?>

</div><!--left-->

<div id="right">
<?php include('side_bar.php');?>
</div><!--right-->

<?php include('footer.php');?>