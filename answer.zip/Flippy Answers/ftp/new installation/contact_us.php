<?php include('header.php');?>
<div id="left">

<div class="other-box">

<div class="box-title"><h1>Contact Us</h1></div>

<script>
$(document).ready(function()
{
    $('#ContactUs').on('submit', function(e)
    {
        e.preventDefault();
        $('#SubmitButton').attr('disabled', ''); // disable upload button
        //show uploading message
        $(this).ajaxSubmit({
        target: '#output',
        success:  afterSuccess //call function after success
        });
    });
});
 
function afterSuccess()
{
    $('#SubmitButton').removeAttr('disabled'); //enable submit button
    $('#loadding').html('');
}
</script>
<div id="output"></div>
<div id="loadding"></div>

<div class="theForm">

<form action="send_contact.php" id="ContactUs" method="post">

<label>Name</label><input name="name" type="text">

<label>Email</label><input name="email" type="text">

<label>Subject</label><input name="subject" type="text">

<label>Message</label><textarea name="message"></textarea>
<div class="subbtn-div"> 
<button type="submit" class="btns" id="SubmitButton">Send</button>
</div>
</form>
</div>


</div><!--other-box-->

<?php
if(!empty($Ad1)){ ?>
<div class="top-ad">
<?php echo stripslashes($Ad1);?>
</div><!--top-ad-->
<?php } ?>

</div><!--left-->

<div id="right">
<?php include('side_bar.php');?>
</div><!--right-->

<?php include('footer.php');?>