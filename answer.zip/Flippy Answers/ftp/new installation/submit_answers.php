<?php

// Error reporting:
error_reporting(E_ALL^E_NOTICE);

include ("db.php");


if($squ = $mysqli->query("SELECT * FROM settings WHERE id='1'")){

    $settings = mysqli_fetch_array($squ);
	
	$Points = $settings['apts'];
	
	$squ->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

include ("include/answers.class.php");

/*
/	This array is going to be populated with either
/	the data that was sent to the script, or the
/	error messages.
/*/

$Date		        = date("c",time());

$arr = array();
$validates = Comment::validate($arr);

if($validates)
{
	/* Everything is OK, insert to database: */
	
	$AnswerTxt = $mysqli->escape_string($arr['answer']);
	
	$mysqli->query("INSERT INTO answers(username,email,answer,date,uid,qid) VALUES ('".$arr['name']."','".$arr['email']."','".$AnswerTxt."','".$Date."','".$arr['ruid']."','".$arr['qid']."')") or die (mysqli_error());
	
	$mysqli->query("UPDATE questions SET answers=answers+1,new_answers=1 WHERE id='".$arr['qid']."'");
	
	$mysqli->query("UPDATE users SET points=points+'$Points' WHERE uid='".$arr['ruid']."'");
	
	$arr['date'] = date('r',time());
	
	$arr = array_map('stripslashes',$arr);
	
	$insertedComment = new Comment($arr);

	
	echo json_encode(array('status'=>1,'html'=>$insertedComment->markup()));

}
else
{
	/* Outputtng the error messages */
	echo '{"status":0,"errors":'.json_encode($arr).'}';
}

?>