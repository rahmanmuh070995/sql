<?php include('header.php');?>
<div id="left">
<div class="title"><h1>Latest Questions</h1></div>

<?php if(!empty($Ad1)){ ?>
<div class="top-ad">
<?php echo stripslashes($Ad1);?>
</div><!--top-ad-->
<?php }

if($LestSql = $mysqli->query("SELECT * FROM questions LEFT JOIN users ON users.uid=questions.userid WHERE questions.userid=users.uid and questions.active=1 ORDER BY questions.id DESC LIMIT 25")){

    while($LatestRow = mysqli_fetch_array($LestSql)){
		
		$QuName = strtolower($LatestRow['username']);
				
?>
<div class="qu-box">
<div class="av-box"><span class="big"><?php echo $LatestRow['answers'];?></span><br/>Answers</div><!--answers-->
<div class="av-box"><span class="big"><?php echo $LatestRow['views'];?></span><br/>Views</div><!--answers-->
<header class="qu-title">
<a href="question-<?php echo $LatestRow['id'];?>.html"><h2><?php echo stripslashes($LatestRow['title']);?></h2></a>
</header>
<footer class="details"><a href="profile-<?php echo $LatestRow['uid'];?>-<?php echo $QuName;?>.html"><?php echo $LatestRow['username'];?></a> asked <abbr class="timeago" title="<?php echo $LatestRow['date'];?>"></abbr></footer>
</div><!--qu-box-->
<?php

}

	$LestSql->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}
?>

</div><!--left-->

<div id="right">
<?php include('side_bar.php');?>
</div><!--right-->

<?php include('footer.php');?>