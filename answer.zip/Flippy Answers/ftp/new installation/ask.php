<?php include('header.php');?>
<div id="left">
<?php 
if(!isset($_SESSION['username'])){?>
<div class="log-reg">Please <a class="loginbox" href="login.html">login</a> or <a href="register.html" class="loginbox">register</a> to ask your question</div>
<?php }else{ ?>
<div class="other-box">
<div class="box-title"><h1>Ask a Question</h1></div>

<script>
$(document).ready(function()
{
    $('#FromQuestion').on('submit', function(e)
    {
        e.preventDefault();
        $('#submitButton').attr('disabled', ''); // disable upload button
        //show uploading message
        
        $(this).ajaxSubmit({
        target: '#output-login',
        success:  afterSuccess //call function after success
        });
    });
});
 
function afterSuccess()
{
    //$('#FromLogin').resetForm();  // reset form
    $('#submitButton').removeAttr('disabled'); //enable submit button
    $('#loadding').html('');
}

$(document).ready(function() {
      var characters = 140;
    $("#counter").append("You have <strong>"+  characters+"</strong> characters remaining");
    $("#title").keyup(function(){
        if($(this).val().length > characters){
        $(this).val($(this).val().substr(0, characters));
        }
    var remaining = characters -  $(this).val().length;
    $("#counter").html("You have <strong>"+  remaining+"</strong> characters remaining");
    if(remaining <= 10)
    {
        $("#counter").css("color","red");
    }
    else
    {
        $("#counter").css("color","black");
    }
    });
        });
</script>

<div id="loadding"></div>
<div id="output-login"></div>

<div class="theForm">

<form action="submit_question.php" id="FromQuestion" method="post">

<label for="catagory-select">Catagory
<span class="small">Please select a category</span>
</label>
<select name="catagory-select" id="catagory-select">
	<option value="">Select a Category</option>
<?php
if($CatSelect = $mysqli->query("SELECT id, cname FROM categories")){

    while($CatsRow = mysqli_fetch_array($CatSelect)){
				
?>
  <option value="<?php echo $CatsRow['id'];?>"><?php echo $CatsRow['cname'];?></option>
<?php

}

	$CatSelect->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}
?>   
</select> 

<label for="title">Question
<span class="small">Brief description of your question</span>
</label>
<input type="text" name="title" id="title" value="" /> 
<div  id="counter"></div> 
   
<label for="question">Question Details
<span class="small">Ask with more details (optional)</span>
</label>
<textarea name="question" id="question"></textarea>     

<div class="subbtn-div"> 
<button type="submit" class="btns" id="submitButton">Login</button>
</div>

</form>
</div>

</div><!--qu-box-->

<?php }
if(!empty($Ad1)){ ?>
<div class="top-ad">
<?php echo stripslashes($Ad1);?>
</div><!--top-ad-->
<?php } ?>

</div><!--left-->

<div id="right">
<?php include('side_bar.php');?>
</div><!--right-->

<?php include('footer.php');?>