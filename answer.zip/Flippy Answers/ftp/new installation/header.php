<?php session_start();
include('db.php');

if($squ = $mysqli->query("SELECT * FROM settings WHERE id='1'")){

    $settings = mysqli_fetch_array($squ);
	
	$template = $settings['template'];
	
	$squ->close();
	
}else{
    
	 printf("Error: %s\n", $mysqli->error);
}

//User Info

if(!isset($_SESSION['username'])){
	
	$Uid = 0;

}else{
	
$Uname = $_SESSION['username'];

if($UserSql = $mysqli->query("SELECT * FROM users WHERE username='$Uname'")){

    $UserRow = mysqli_fetch_array($UserSql);
	
	$UsName = strtolower($UserRow['username']);

	$Uid = $UserRow['uid'];
	
	$UserEmail = $UserRow['email'];
	
	$Uavatar = $UserRow['avatar'];

    $UserSql->close();
	
}else{
     
	 printf("Error: %s\n", $mysqli->error);
	 
}

}

//Page titles

$urlTitle = parse_url($_SERVER['REQUEST_URI']);

$pageName = $urlTitle['path'];
if($pageName == '/about_us.html'){
	$pageTitle = 'About Us | ';
} else if($pageName ==  '/contact_us.html'){
	$pageTitle = 'Contact Us | ';
} else if($pageName ==  '/privacy_policy.html'){
	$pageTitle = 'Privacy Policy | ';
} else if($pageName ==  '/tos.html'){
	$pageTitle = 'Terms of Use | ';
} else if($pageName ==  '/faq.html'){
	$pageTitle = 'Frequently Asked Questions | ';	
} else if($pageName ==  '/edit_profile.html'){
	$pageTitle = 'Edit My Profile | ';
} else if($pageName ==  '/edit_profile.html'){
	$pageTitle = 'Edit Your Info | ';
} else if($pageName ==  '/ask.html'){
	$pageTitle = 'Ask a Question | ';
						
} else {
	$pageTitle = '';
}

//Ads

if($AdsSql = $mysqli->query("SELECT * FROM siteads WHERE id='1'")){

    $AdsRow = mysqli_fetch_array($AdsSql);
	
	$Ad1 = $AdsRow['ad1'];
	$Ad2 = $AdsRow['ad2'];

    $AdsSql->close();

}else{
	
     printf("Error: %s\n", $mysqli->error);
}

$UpdateSiteViews = $mysqli->query("UPDATE settings SET site_hits=site_hits+1 WHERE id=1");

?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo $pageTitle;?><?php echo $settings['name']; ?></title>
<meta name="description" content="<?php echo $settings['descrp']; ?>" />
<meta name="keywords" content="<?php echo $settings['keywords']; ?>" />

<link href="favicon.ico" rel="shortcut icon" type="image/x-icon"/>

<link href="templates/<?php echo $settings['template'];?>/css/style.css" rel="stylesheet" type="text/css">

<!--[if lt IE 9]>
<script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.form.js"></script>
<script src="js/jquery.colorbox-min.js"></script>
<script type="text/javascript" src="js/jquery.freeow.min.js"></script>
<script src="js/jquery.timeago.js" type="text/javascript"></script>

<script type="text/javascript">
$(document).ready(function(){
	$(".login-links").colorbox();
	$(".loginbox").colorbox();
})
jQuery(document).ready(function() {
  jQuery("abbr.timeago").timeago();
});

$(document).scroll(function() {
    
    var useFixedNav = $(document).scrollTop() > 75;
    $('.menu-bar').toggleClass('menu-bar-fixed', useFixedNav);
    
});

</script>
</head>

<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1&appId=196505667225847";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<header id="main-header">
<section id="head-container">
<div id="logo"><a href="index.html"><img src="images/logo.png" alt="<?php echo $settings['name'];?>" width="200" height="70"></a></div>
<div id="login-box">
<?php if(!isset($_SESSION['username'])){?>
<a href="login.html" class="login-links">Login</a> | <a href="register.html" class="login-links">Register</a>
<?php }else{ ?>
Welcome <?php echo ucfirst($_SESSION['username']);}?>
</div><!--login-box-->
</section><!--head-container-->

<div class="menu-bar">
<div id="menu-center">
<nav id="top-menu">
<ul>
   <li class='active'><a href='index.html'><span>Home</span></a></li>
   <li><a href="all.html"><span>All Questions</span></a></li>
   <li><a href="answerd.html"><span>Answerd</span></a></li>
   <li><a href="unanswered.html"><span>Unanswered</span></a></li>
   <li class="last"><a href="ask.html"><span>Ask</span></a></li>
</ul>
</nav>

<div class="search-box">
<form name="search" id="search" method="get" action="search.php">
<input type="text" tabindex="1" class="input" id="term" name="term" placeholder="Search questions and answers"/>
<button type="submit" tabindex="2" class="form-button" id="submit-search">Search</button>
</form>
</div>

</div><!--menu-center-->
</div><!--menu-bar-->
</header>
<div id="container">
<div id="freeow" class="freeow freeow-top-right"></div>