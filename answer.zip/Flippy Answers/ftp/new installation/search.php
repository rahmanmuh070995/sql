<?php include('header.php');?>
<div id="left">
<?php

$term = $mysqli->escape_string($_GET['term']);

?>
 
<div class="title"><h1>Search results for "<?php echo $term;?>"</h1></div>
<?php if(!empty($Ad1)){ ?>
<div class="top-ad">
<?php echo stripslashes($Ad1);?>
</div><!--top-ad-->
<?php } 

error_reporting(E_ALL ^ E_NOTICE);
// How many adjacent pages should be shown on each side?
	$adjacents = 5;
	
	$query = $mysqli->query("SELECT COUNT(*) as num FROM questions LEFT JOIN users ON users.uid=questions.userid WHERE questions.userid=users.uid and questions.active=1 and (questions.title  like '%$term%' or questions.question like '%$term%') ORDER BY id  DESC");
	$total_pages = mysqli_fetch_array($query);
	$total_pages = $total_pages['num'];
	
	$limit = 15; 								//how many items to show per page
	$page = $_GET['page'];
	 
	if($page) 
		$start = ($page - 1) * $limit; 			//first item to display on this page
	else
		$start = 0;								//if no page var is given, set start to 0
 	/* Get data. */
	$result = $mysqli->query("SELECt * FROM questions LEFT JOIN users ON users.uid=questions.userid WHERE questions.userid=users.uid and questions.active=1 and (questions.title  like '%$term%' or questions.question like '%$term%') ORDER BY id DESC LIMIT $start, $limit");
	 
	//$result = $mysqli->query($sql);
	
	/* Setup page vars for display. */
	if ($page == 0) $page = 1;					//if no page var is given, default to 1.
	$prev = $page - 1;							//previous page is page - 1
	$next = $page + 1;							//next page is page + 1
	$lastpage = ceil($total_pages/$limit);		//lastpage is = total pages / items per page, rounded up.
	$lpm1 = $lastpage - 1;						//last page minus 1
	
	$pagination = "";
	if($lastpage > 1)
	{	
		$pagination .= "<div class=\"pagination\">";
		//previous button
		if ($page > 1) 
			$pagination.= "<a href=\"search.php?term=$term&page=$prev\">« previous</a>";
		else
			$pagination.= "<span class=\"disabled\">« previous</span>";	
		
		//pages	
		if ($lastpage < 7 + ($adjacents * 2))	//not enough pages to bother breaking it up
		{	
			for ($counter = 1; $counter <= $lastpage; $counter++)
			{
				if ($counter == $page)
					$pagination.= "<span class=\"current\">$counter</span>";
				else
					$pagination.= "<a href=\"search.php?term=$term&page=$counter\">$counter</a>";					
			}
		}
		elseif($lastpage > 5 + ($adjacents * 2))	//enough pages to hide some
		{
			//close to beginning; only hide later pages
			if($page < 1 + ($adjacents * 2))		
			{
				for ($counter = 1; $counter < 4 + ($adjacents * 2); $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"search.php?term=$term&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"search.php?term=$term&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"search.php?term=$term&page=$lastpage\">$lastpage</a>";		
			}
			//in middle; hide some front and some back
			elseif($lastpage - ($adjacents * 2) > $page && $page > ($adjacents * 2))
			{
				$pagination.= "<a href=\"search.php?term=$term&page=1\">1</a>";
				$pagination.= "<a href=\"search.php?term=$term&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $page - $adjacents; $counter <= $page + $adjacents; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"search.php?term=$term&page=$counter\">$counter</a>";					
				}
				$pagination.= "...";
				$pagination.= "<a href=\"search.php?term=$term&page=$lpm1\">$lpm1</a>";
				$pagination.= "<a href=\"search.php?term=$term&page=$lastpage\">$lastpage</a>";		
			}
			//close to end; only hide early pages
			else
			{
				$pagination.= "<a href=\"search.php?term=$term&page=1\">1</a>";
				$pagination.= "<a href=\"search.php?term=$term&page=2\">2</a>";
				$pagination.= "...";
				for ($counter = $lastpage - (2 + ($adjacents * 2)); $counter <= $lastpage; $counter++)
				{
					if ($counter == $page)
						$pagination.= "<span class=\"current\">$counter</span>";
					else
						$pagination.= "<a href=\"search.php?term=$term&page=$counter\">$counter</a>";					
				}
			}
		}
		
		//next button
		if ($page < $counter - 1) 
			$pagination.= "<a href=\"search.php?term=$term&page=$next\">next »</a>";
		else
			$pagination.= "<span class=\"disabled\">next »</span>";
		$pagination.= "</div>\n";		
	}
	
	$q= $mysqli->query("SELECt * FROM questions LEFT JOIN users ON users.uid=questions.userid WHERE questions.userid=users.uid and questions.active=1 and (questions.title  like '%$term%' or questions.question like '%$term%') ORDER BY id DESC limit $start,$limit");
	

	$numr = mysqli_num_rows($q);
	if ($numr==0)
	{
	echo '<div id="search-results">
	<h3>Your search for "<span class="tt-text">'.$term.'</span>" did not produce any results</h3>
	<ul class="search-again">
	<li>Make sure all words are spelled correctly</li>
	<li>Try different keywords</li>
	<li>Try more general keywords</li>
	</ul>	
	</div>';
	}
	while($row=mysqli_fetch_assoc($q)){		
		
		$QuName = strtolower($row['username']);	
?>
<div class="qu-box">
<div class="av-box"><span class="big"><?php echo $row['answers'];?></span><br/>Answers</div><!--answers-->
<div class="av-box"><span class="big"><?php echo $row['views'];?></span><br/>Views</div><!--answers-->
<header class="qu-title">
<a href="question-<?php echo $row['id'];?>.html"><h2><?php echo stripslashes($row['title']);?></h2></a>
</header>
<footer class="details"><a href="profile-<?php echo $row['uid'];?>-<?php echo $QuName;?>.html"><?php echo $row['username'];?></a> asked <abbr class="timeago" title="<?php echo $row['date'];?>"></abbr></footer>
</div><!--qu-box-->
<?php } ?>
		
<div class="pagediv"><?php echo $pagination;?></div>

</div><!--left-->

<div id="right">
<?php include('side_bar.php');?>
</div><!--right-->

<?php include('footer.php');?>