<?php include('header.php');?>
<div class="maintitle">Dashboard</div>
<div class="box-top">
<div class="inbox">
<div class="leftTable">
<table width="455" class="datatable" border="0" cellspacing="0" cellpadding="0">
<thead>
  <tr>
    <td width="300">Site Statistics</td>
    <td width="160"></td>
   </tr>
 </thead>
<tbody>
<tr>
    <td>Total Site Views</td>

     <td><?php echo $settings['site_hits'];?></td>
</tr>
<tr>
<td>Total Users</td>
<?php
$totsale = $mysqli->query("SELECT uid, username FROM users ORDER BY uid DESC") or die ($mysqli->query());
$latest = mysqli_fetch_array($totsale);
$totsalenum = mysqli_num_rows($totsale);   
?>     
<td><?php echo $totsalenum;?></td>
</tr>
<tr>
    <td>Latest User</td>
   <td><?php echo $latest['username'];?></td>
</tr>
</tbody>
</table> 
</div>
<!--#-->
<div class="rightTable">
<table width="455" class="datatable" border="0" cellspacing="0" cellpadding="0">
<thead>
  <tr>
    <td width="300">Question and Answer Statistics</td>
    <td width="160"></td>
   </tr>
 </thead>
<tbody>
<tr>
    <td>Total Questions</td>
<?php
$TotAnswered = $mysqli->query("SELECT id FROM questions") or die ($mysqli_eroor());
$QuestionsnCnt = mysqli_num_rows($TotAnswered);   
?>     
	 <td><?php echo $QuestionsnCnt;?></td>
</tr>
<tr>
    <td>Total Answered Questions</td>
<?php    
$TotAnswered = $mysqli->query("SELECT id FROM questions WHERE answers>0") or die ($mysqli_eroor());
$AnsweredCnt = mysqli_num_rows($TotAnswered);
      
?>      
    <td><?php echo $AnsweredCnt;?></td>
</tr>
<tr>
    <td>Total Answers</td>
<?php    
$TotAnswers = $mysqli->query("SELECT id FROM answers") or die ($mysqli_eroor());
$AnswerCnt = mysqli_num_rows($TotAnswers);   
?>     
    <td><?php echo $AnswerCnt;?></td>
</tr>
</tbody>
</table> 
</div>
</div>
</div>
<div class="clear"></div>
<!--#-->

<div class="maintitle">Last 10 Answered Questions</div>
<div class="box-top">
<div class="inbox">

<table width="925" class="datatable" border="0" cellspacing="0" cellpadding="0">
<thead>
  <tr>
    <td width="678">Question</td>
    <td width="150">Asked On</td>
   </tr>
 </thead>
<tbody>
	<?php
	$Questions = $mysqli->query("SELECT * FROM questions WHERE answers>0 ORDER BY id DESC LIMIT 10") or die (mysqli_error()); 
		while($QuestionsRow = mysqli_fetch_array($Questions))
		{									
			?>
		<tr>
    <td><a href="../question-<?php echo $QuestionsRow['id'];?>.html" target="_blank"><?php echo stripslashes($QuestionsRow['title']);?></a></td>
    <td><abbr class="timeago" title="<?php echo $QuestionsRow['date'];?>"></abbr></td>
</tr>
	
<?php }	?>
 </tbody>
</table> 

</div>
</div><!--box-->


<div class="maintitle">Last 10 Unanswered Questions</div>
<div class="box-top">
<div class="inbox">

<table width="925" class="datatable" border="0" cellspacing="0" cellpadding="0">
<thead>
  <tr>
    <td width="678">Question</td>
    <td width="150">Asked On</td>
   </tr>
 </thead>
<tbody>
	<?php
	$UnQuestions = $mysqli->query("SELECT * FROM questions WHERE answers=0 ORDER BY id DESC LIMIT 10") or die (mysqli_error()); 
		while($UnQuestionsRow = mysqli_fetch_array($UnQuestions))
		{									
			?>
		<tr>
    <td><a href="../question-<?php echo $UnQuestionsRow['id'];?>.html" target="_blank"><?php echo stripslashes($UnQuestionsRow['title']);?></a></td>
    <td><abbr class="timeago" title="<?php echo $UnQuestionsRow['date'];?>"></abbr></td>
</tr>
	
<?php }	?>
 </tbody>
</table> 

</div>
</div><!--box-->
<?php include('footer.php');?>

 