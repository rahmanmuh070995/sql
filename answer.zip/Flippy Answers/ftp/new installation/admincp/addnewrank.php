<?php include("header.php");?>
<div class="maintitle">Add New Rank</div>

<?php
$act=isset($_GET['act'])?$_GET['act']:"";
if($act=='sub'){
	
$Rank = $mysqli->escape_string($_POST['rank']);
$Pts = $mysqli->escape_string($_POST['pts']);

$AddRank =$mysqli->query("INSERT INTO ranks(rank,points)VALUES ('".$Rank."','".$Pts."')");?>

<div class="msg-ok">New rank added successfully</div>

<?php }?>

<div class="box">
<div class="inbox">

<form name="newrank" action="addnewrank.php?act=sub" method="post">

<label class="artlbl" for="cat">Rank:</label>
<div class="formdiv"><input  name="rank" class="biginput" type="text" value=""/></div>

<label class="artlbl" for="cat">Points Required:</label>
<div class="formdiv"><input  name="pts" class="biginput" type="text" value=""/></div>
</div>

<div class="formdiv"><input type="submit" id="submit"value='Save Rank'/></div>
</form>
</div>
</div>	
<?php include("footer.php");?>